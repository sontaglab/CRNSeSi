% starting from old_find_signs.m but making stoichiometry combinations

% starting from do25oct.m but now making more general
% uses these files (best to do symlinks for particular cases):


% these depend on examples:

% ABGN.m          stoichiometry and defines N
% names_vars.m    names of variables, just for display purposes
% make_virtual_constraints virtual species/constraints if any (e.g. tot protein)
% make_initial_stoichiometric_constraints;


% these are common to all:

% additional_stoichiometry 

clear

% load total #N species and stoichiometry matrix
ABGN;

% load names of variables, just for display purposes
names_vars;

% vector that will contain all rows to test
all_n=[];

% filter: only keep that pass test of disjoint parts for nu . Gamma signs
constraints = [];

display('generating first single rows of n*G*A^T that pass test');
Ide = eye(N);
for i = 1:N
    n = Ide(i,:);
    ans=testn(A,B,n);
    if ans==1
%       n  %print if want to see which used
       constraints = [constraints;n*G*A'];
       all_n = [all_n;n];
    end
end

% now add all pairs and filter them, as above

new_constraints=[];

% generates additional n's - adjust if needed to do less sparse/larger integers
  generate_additional_n;  % returns "additional_n" list of vectors "nu"

% testing the additional ones, and adding them to all_n list, and saving the
%  n*G*A' vectors into new_constraints
%  (not sure why I didn't directly add them; also legacy code, could have
%  tested all at once, more elegantly

display('testing the new vectors and adding to list the ones that pass');
how_many_additional = size(additional_n,1);
for i = 1:how_many_additional
    n = additional_n(i,:);
        ans=testn(A,B,n);
    if ans==1
       new_constraints = [new_constraints;n*G*A'];
       all_n = [all_n;n];
    end
end

% this is the number of constraints:

how_many_original_constraints = size(all_n,1);

%display('debug: these two should be the same:')
%size(constraints)
%size(all_n)

fprintf('total number of constraints so far = %4.0f, listed below\n',how_many_original_constraints);

constraints = [constraints;new_constraints]

make_initial_stoichiometric_constraints;

how_many_stoichiometry=size(stoichiometry_constraints,1);

fprintf('total number of initial stoichiometry constraints = %4.0f, listed below\n',how_many_stoichiometry);

stoichiometry_constraints

constraints=[constraints;stoichiometry_constraints];

 how_many_stoichiometry

% march 2014: adding exit if only one stoichiometry:
if how_many_stoichiometry>1
  generate_combinations_stoichiometry;
  how_many_additional_stoichiometry = size(additional_stoichiometry,1);
else
  how_many_additional_stoichiometry = 0;
  additional_stoichiometry=[];
end

fprintf('total number of added stoichiometry constraints = %4.0f, listed below\n',how_many_additional_stoichiometry);

stoichiometry_constraints = [stoichiometry_constraints;additional_stoichiometry];
constraints = [constraints;additional_stoichiometry];

how_many_stoichiometry = how_many_stoichiometry + how_many_additional_stoichiometry;

% add virtual species and constraints if any (for e.g. total forms of a protein)
make_virtual_constraints

how_many_virtual = size(virtual,1);

fprintf('total number of virtual constraints = %4.0f, listed below\n',how_many_virtual);

if how_many_virtual > 0 
  constraints = [constraints;virtual];
end

howmanyconstraints = size(constraints,1);
fprintf('total number of constraints so far = %4.0f, listed below\n',howmanyconstraints);
constraints

%generate pi vectors to test
  D = [0:(3^N-3)/2]';
% last (3^N+1)/2:3^N (in reverse order) = 1:(3^N-1)/2; all-zero is (3^N+1)/2
% because when generating ternary numbers, replacing 0 by 2 and viceversa is
% the same as saying numbers add to 3^N
% i.e., [0:(3^N-3)/2] is same as "flipud" of rows for [(3^N+1)/2:3^N-1]
  AA = dec2base(D, 3);
  BB = str2mat(AA);
  possible_signs = BB-49;
% the 49 is because ascii(0)=48, so this makes 012->-1,0,1

% trim using constraints:
old_count=size(possible_signs,1);
fprintf('how many possible signs: %5.0f\n',old_count)

% for debugging only, set timer
%tic

for i = 1:howmanyconstraints

% for debugging only, print iteration:
%toc
%i
%tic

      possible_signs = checkcontraint(constraints(i,:),possible_signs);
% report how many left
      howmany_possible_signs = size(possible_signs,1);
      if howmany_possible_signs < old_count
        fprintf('after using constraint %5.0f, possible signs left: %5.0f\n',i,howmany_possible_signs)
        disp('constraint used is:')
        disp(constraints(i,:))
        if i<=how_many_original_constraints
           disp('corresponding to this combination of species:');
           disp(all_n(i,:))
        elseif i<=how_many_original_constraints+how_many_stoichiometry
           display('corresponding to this stoichiometry constraint:');
           disp(stoichiometry_constraints(i-how_many_original_constraints,:))
        else
           disp('corresponding to this virtual constraint:');
           disp(virtual(i-how_many_original_constraints-how_many_stoichiometry,:))
        end
        old_count=howmany_possible_signs;
      end
end

display('ended search')
display(' ');

%stoichiometry_constraints
%fprintf('%s\n',varnames)
%display(' ');

possible_signs
fprintf('%s\n',varnames)

%display(' ');
%display('symmetry check, all add to zero; same stds?:')
%[mean(possible_signs);std(possible_signs)]

