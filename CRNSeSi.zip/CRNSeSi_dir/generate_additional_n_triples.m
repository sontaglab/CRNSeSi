display('next, generating combinations 1-1, 1+1, 1+2, 1-2, 2-1, 2+1 of rows')
display('and also all 1+3,1-3,3+1,3-1,2+3,2-3,2+2,3-2')
display('and also triples 1+1+1, 1+1-1, 1-1+1, 1-1-1')

additional_n=[];

% generate all 1,-1's
for i = 1:N
    for j = i+1:N
        new_one = zeros(1,N);
        new_one(i)=1;
        new_one(j)=-1;
        additional_n = [additional_n;new_one];
    end
end

% generate all 1,1's
for i = 1:N
    for j = i+1:N
        new_one = zeros(1,N);
        new_one(i)=1;
        new_one(j)=1;
        additional_n = [additional_n;new_one];
    end
end

% generate all 1,2's
for i = 1:N
    for j = i+1:N
        new_one = zeros(1,N);
        new_one(i)=1;
        new_one(j)=2;
        additional_n = [additional_n;new_one];
    end
end

% generate all 1,-2's
for i = 1:N
    for j = i+1:N
        new_one = zeros(1,N);
        new_one(i)=1;
        new_one(j)=-2;
        additional_n = [additional_n;new_one];
    end
end

% generate all 2,-1's
for i = 1:N
    for j = i+1:N
        new_one = zeros(1,N);
        new_one(i)=2;
        new_one(j)=-1;
        additional_n = [additional_n;new_one];
    end
end

% generate all 2,1's
for i = 1:N
    for j = i+1:N
        new_one = zeros(1,N);
        new_one(i)=2;
        new_one(j)=1;
        additional_n = [additional_n;new_one];
    end
end

% generate all 3,1's
for i = 1:N
    for j = i+1:N
        new_one = zeros(1,N);
        new_one(i)=3;
        new_one(j)=1;
        additional_n = [additional_n;new_one];
    end
end

% generate all 3,-1's
for i = 1:N
    for j = i+1:N
        new_one = zeros(1,N);
        new_one(i)=3;
        new_one(j)=-1;
        additional_n = [additional_n;new_one];
    end
end

% generate all 3,2's
for i = 1:N
    for j = i+1:N
        new_one = zeros(1,N);
        new_one(i)=3;
        new_one(j)=2;
        additional_n = [additional_n;new_one];
    end
end

% generate all 3,-2's
for i = 1:N
    for j = i+1:N
        new_one = zeros(1,N);
        new_one(i)=3;
        new_one(j)=-2;
        additional_n = [additional_n;new_one];
    end
end

% generate all 1,3's
for i = 1:N
    for j = i+1:N
        new_one = zeros(1,N);
        new_one(i)=1;
        new_one(j)=3;
        additional_n = [additional_n;new_one];
    end
end

% generate all 1,-3's
for i = 1:N
    for j = i+1:N
        new_one = zeros(1,N);
        new_one(i)=1;
        new_one(j)=-3;
        additional_n = [additional_n;new_one];
    end
end

    % generate all 2,3's
for i = 1:N
    for j = i+1:N
        new_one = zeros(1,N);
        new_one(i)=2;
        new_one(j)=3;
        additional_n = [additional_n;new_one];
    end
end

% generate all 2,-3's
for i = 1:N
    for j = i+1:N
        new_one = zeros(1,N);
        new_one(i)=2;
        new_one(j)=-3;
        additional_n = [additional_n;new_one];
    end
end

% generate all 1,1,1's
for i = 1:N
    for j = i+1:N
        for k = j+1:N
        new_one = zeros(1,N);
        new_one(i)=1;
        new_one(j)=1;
        new_one(k)=1;
        additional_n = [additional_n;new_one];
    end
  end
end

% generate all 1,1,-1's
for i = 1:N
    for j = i+1:N
        for k = j+1:N
        new_one = zeros(1,N);
        new_one(i)=1;
        new_one(j)=1;
        new_one(k)=-1;
        additional_n = [additional_n;new_one];
    end
  end
end

% generate all 1,-1,1's
for i = 1:N
    for j = i+1:N
        for k = j+1:N
        new_one = zeros(1,N);
        new_one(i)=1;
        new_one(j)=-1;
        new_one(k)=1;
        additional_n = [additional_n;new_one];
    end
  end
end

% generate all 1,-1,-1's
for i = 1:N
    for j = i+1:N
        for k = j+1:N
        new_one = zeros(1,N);
        new_one(i)=1;
        new_one(j)=-1;
        new_one(k)=-1;
        additional_n = [additional_n;new_one];
    end
  end
end

%debug:
%additional_n

