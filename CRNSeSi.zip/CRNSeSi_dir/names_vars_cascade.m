varnames = '     e    m0     a    m1     g     b    n0     c    n1     f     d';
