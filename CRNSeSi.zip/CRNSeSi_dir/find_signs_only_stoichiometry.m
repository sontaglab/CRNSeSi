clear


% variation in which I have already obtained signs without considering additional artificial variables, which are (assumed unique; change code to allow non-unique):

  num_artificial = 2;  % hardwiring this, change as needed:


%% for make_cascade_fix_GT_FT_MT_NT.sh  i.e. changing ET first kinase
%initial_signs = [...
%    -1     1    -1    -1     1    -1     1    -1    -1     1    -1]
%%    e    m0     a    m1     g     b    n0     c    n1     f     d

%% for make_cascade_fix_ET_GT_FT_NT.sh  i.e. changing MT first substrate
%initial_signs = [...
%    -1     1     1     1    -1     1    -1     1     1    -1     1]
%%    e    m0     a    m1     g     b    n0     c    n1     f     d

%% for make_cascade_fix_ET_FT_MT_NT.sh  i.e. changing GT first phosphotase
%initial_signs = [...
%    -1     1     1    -1     1     1     1    -1    -1     1    -1]
%%    e    m0     a    m1     g     b    n0     c    n1     f     d

%% for make_cascade_fix_ET_GT_FT_MT.sh  i.e. changing NT second substrate
%initial_signs = [...
%    -1     1     1     1    -1     1    -1    -1    -1     1    -1]
%%    e    m0     a    m1     g     b    n0     c    n1     f     d

% for make_cascade_fix_ET_GT_MT_NT.sh  i.e. changing FT second phosphotase
initial_signs = [...
    -1     1     1     1    -1     1    -1    -1     1    -1    -1]
%    e    m0     a    m1     g     b    n0     c    n1     f     d



% extracting now from previous code:

% ABGN.m          stoichiometry and defines N
% names_vars.m    names of variables, just for display purposes
% make_virtual_constraints virtual species/constraints if any (e.g. tot protein)
% make_initial_stoichiometric_constraints;

% these are common to all:

% additional_stoichiometry 

% load total #N species and stoichiometry matrix
ABGN;

% load names of variables, just for display purposes
names_vars;

% vector that will contain all rows to test
all_n=[];

%% filter: only keep that pass test of disjoint parts for nu . Gamma signs
constraints = [];
%
%new_constraints=[];
%
%% this is the number of constraints:
%
how_many_original_constraints = 0;
%
%%display('debug: these two should be the same:')
%%size(constraints)
%%size(all_n)
%
%fprintf('total number of constraints so far = %4.0f, listed below\n',how_many_original_constraints);

%constraints = [constraints;new_constraints]

make_initial_stoichiometric_constraints;
addxy

how_many_stoichiometry=size(stoichiometry_constraints,1);

fprintf('total number of initial stoichiometry constraints = %4.0f, listed below\n',how_many_stoichiometry);

stoichiometry_constraints

constraints = stoichiometry_constraints;

generate_combinations_stoichiometry

how_many_additional_stoichiometry = size(additional_stoichiometry,1);

fprintf('total number of added stoichiometry constraints = %4.0f, listed below\n',how_many_additional_stoichiometry);

additional_stoichiometry

stoichiometry_constraints = [stoichiometry_constraints;additional_stoichiometry];
constraints = [constraints;additional_stoichiometry];

how_many_stoichiometry = how_many_stoichiometry + how_many_additional_stoichiometry;

% add virtual species and constraints if any (for e.g. total forms of a protein)
make_virtual_constraints

how_many_virtual = size(virtual,1);

fprintf('total number of virtual constraints = %4.0f, listed below\n',how_many_virtual);

if how_many_virtual > 0 
  constraints = [constraints;virtual];
end

howmanyconstraints = size(constraints,1);
fprintf('total number of constraints so far = %4.0f, listed below\n',howmanyconstraints);
constraints


% I only need to generate values for the additional variables


Na = num_artificial;
repeated1s = ones(3^Na,1);

%generate pi vectors to test; NOTE! MUST include negatives, since first parts already are mod negatives!
D = [0:8];
%  D = [0:(3^Na-3)/2]';
  AA = dec2base(D, 3);
  BB = str2mat(AA);
  possible_signs = BB-49;
% the 49 is because ascii(0)=48, so this makes 012->-1,0,1

initial_repeated = repeated1s*initial_signs;

possible_signs = [initial_repeated,possible_signs];

% trim using constraints:
old_count=size(possible_signs,1);
fprintf('how many possible signs: %5.0f\n',old_count)

% for debugging only, set timer
%tic

for i = 1:howmanyconstraints

% for debugging only, print iteration:
%toc
%i
%tic

%debug:
%  size(constraints)
%  size(possible_signs)

      possible_signs = checkcontraint(constraints(i,:),possible_signs);
% report how many left
      howmany_possible_signs = size(possible_signs,1);
      if howmany_possible_signs < old_count
        fprintf('after using constraint %5.0f, possible signs left: %5.0f\n',i,howmany_possible_signs)
        disp('constraint used is:')
        disp(constraints(i,:))
        if i<=how_many_original_constraints
           disp('corresponding to this combination of species:');
           disp(all_n(i,:))
        elseif i<=how_many_original_constraints+how_many_stoichiometry
           display('corresponding to this stoichiometry constraint:');
           disp(stoichiometry_constraints(i-how_many_original_constraints,:))
        else
           disp('corresponding to this virtual constraint:');
           disp(virtual(i-how_many_original_constraints-how_many_stoichiometry,:))
        end
        old_count=howmany_possible_signs;
      end
end

display('ended search')
display(' ');

%stoichiometry_constraints
%fprintf('%s\n',varnames)
%display(' ');

possible_signs
fprintf('%s\n',varnames)

%display(' ');
%display('symmetry check, all add to zero; same stds?:')
%[mean(possible_signs);std(possible_signs)]

