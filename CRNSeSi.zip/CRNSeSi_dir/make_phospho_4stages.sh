/bin/rm ABGN.m
/bin/rm make_virtual_constraints.m
/bin/rm make_initial_stoichiometric_constraints.m
/bin/rm names_vars.m

ln -s ABGN_phosphotransfer_4stages.m ABGN.m
ln -s make_initial_stoichiometric_constraints_phosphotransfer_4stages.m make_initial_stoichiometric_constraints.m
ln -s names_vars_phosphotransfer_4stages.m names_vars.m
ln -s make_virtual_constraints_phosphotransfer_4_steps.m make_virtual_constraints.m
