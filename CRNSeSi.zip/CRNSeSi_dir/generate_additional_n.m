display('next, generating combinations 1-1, 1+1, 1+2, 1-2, 2-1, 2+1 of rows')

additional_n=[];

% generate all 1,-1's
for i = 1:N
    for j = i+1:N
        new_one = zeros(1,N);
        new_one(i)=1;
        new_one(j)=-1;
        additional_n = [additional_n;new_one];
    end
end

% generate all 1,1's
for i = 1:N
    for j = i+1:N
        new_one = zeros(1,N);
        new_one(i)=1;
        new_one(j)=1;
        additional_n = [additional_n;new_one];
    end
end

% generate all 1,2's
for i = 1:N
    for j = i+1:N
        new_one = zeros(1,N);
        new_one(i)=1;
        new_one(j)=2;
        additional_n = [additional_n;new_one];
    end
end

% generate all 1,-2's
for i = 1:N
    for j = i+1:N
        new_one = zeros(1,N);
        new_one(i)=1;
        new_one(j)=-2;
        additional_n = [additional_n;new_one];
    end
end

% generate all 2,-1's
for i = 1:N
    for j = i+1:N
        new_one = zeros(1,N);
        new_one(i)=2;
        new_one(j)=-1;
        additional_n = [additional_n;new_one];
    end
end

% generate all 2,1's
for i = 1:N
    for j = i+1:N
        new_one = zeros(1,N);
        new_one(i)=2;
        new_one(j)=1;
        additional_n = [additional_n;new_one];
    end
end

%debug:
%additional_n
