varnames = '    L1    L1p   L2    L2p   L3    L3p    L4   L4p';
