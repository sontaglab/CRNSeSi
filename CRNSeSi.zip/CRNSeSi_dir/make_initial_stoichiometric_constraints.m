% keep L1 constant
% rows:  L1 L1p L2 L2p L3 L3p L4 L4p
  L1T  = [1   1  0   0  0   0  0   0];

% keep L2 constant
% rows:  L1 L1p L2 L2p L3 L3p L4 L4p
  L2T  = [0   0  1   1  0   0  0   0];

% keep L3 constant
% rows:  L1 L1p L2 L2p L3 L3p L4 L4p
  L3T  = [0   0  0   0  1   1  0   0];

stoichiometry_constraints = [L1T;L2T;L3T];

