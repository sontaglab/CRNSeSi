display('adding virtual constraint(s), if any')

virtual = [];
