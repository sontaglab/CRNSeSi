function XNOR = testsp(s,p)
%  display('calling testsp')
  z = s.*p;
  p = sign(sum(z>0));
  q = sign(sum(z<0));
  XNOR = sign(p*q + (1-p)*(1-q));
end
