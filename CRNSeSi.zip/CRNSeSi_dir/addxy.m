howmany_true_stoichiometric=4;  % needed for book-keeping in this script

% already set stoichiometry_constraints

% artificial species added to be able to display certain objects of interest, such as X and Y = total of an enzyme in bound or unbound form

num_artificial=2;

num_reactions=size(G,2);
artificial = zeros(num_artificial,num_reactions);

G = [G;artificial]
B =  (G>0).*G;
A = -(G<0).*G;

N=N+num_artificial;

% add zeroes to the previous constraints and stoichiometric constraints, to place-hold artificial species

howmanyconstraints = size(constraints,1);
addcols1 = zeros(howmanyconstraints,num_artificial);
constraints = [constraints,addcols1];
addcols2 = zeros(howmany_true_stoichiometric,num_artificial);
stoichiometry_constraints = [stoichiometry_constraints,addcols2];

% X = M1 + B + C
% Y = N1 + D

artificial_constraints = [...
%E  M0 A  M1 G  B  N0 C  N1 F  D  X  Y
 0  0  0  1  0  1  0  1  0  0  0 -1  0
 0  0  0  0  0  0  0  0  1  0  1  0 -1];

stoichiometry_constraints = [stoichiometry_constraints;artificial_constraints];
