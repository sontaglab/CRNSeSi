display('adding virtual constraint(s), if any')

% rows:  L1  L1p L2  L2p  L3 L3p L4 L4p
virtual= [1   0   0   0   0  0   0  -1];

