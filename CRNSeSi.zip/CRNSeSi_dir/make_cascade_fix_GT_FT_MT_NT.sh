/bin/rm ABGN.m
/bin/rm make_virtual_constraints.m
/bin/rm make_initial_stoichiometric_constraints.m
/bin/rm names_vars.m

ln -s ABGN_cascade.m ABGN.m
ln -s make_initial_stoichiometric_constraints_cascade_fix_GT_FT_MT_NT.m make_initial_stoichiometric_constraints.m
ln -s names_vars_cascade.m names_vars.m
ln -s make_virtual_constraints_empty.m make_virtual_constraints.m
