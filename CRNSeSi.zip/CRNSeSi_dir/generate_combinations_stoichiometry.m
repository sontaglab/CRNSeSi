display('next, generating combinations 1-1, 1+1, 1+2, 1-2, 2-1, 2+1 of stoichiometry')

% really stupid way to do; to make a more elegant code parametrized by largest
% integer, by trick similar to base-3 trick used elsewhere in code, for example 

NN = how_many_stoichiometry;

multipliers=[];

% generate all 1,-1's
for i = 1:NN
    for j = i+1:NN
        new_one = zeros(1,NN);
        new_one(i)=1;
        new_one(j)=-1;
        multipliers = [multipliers;new_one];
    end
end

% generate all 1,1's
for i = 1:NN
    for j = i+1:NN
        new_one = zeros(1,NN);
        new_one(i)=1;
        new_one(j)=1;
        multipliers = [multipliers;new_one];
    end
end

% generate all 1,2's
for i = 1:NN
    for j = i+1:NN
        new_one = zeros(1,NN);
        new_one(i)=1;
        new_one(j)=2;
        multipliers = [multipliers;new_one];
    end
end


% generate all 1,-2's
for i = 1:NN
    for j = i+1:NN
        new_one = zeros(1,NN);
        new_one(i)=1;
        new_one(j)=-2;
        multipliers = [multipliers;new_one];
    end
end


% generate all 2,-1's
for i = 1:NN
    for j = i+1:NN
        new_one = zeros(1,NN);
        new_one(i)=2;
        new_one(j)=-1;
        multipliers = [multipliers;new_one];
    end
end

% generate all 2,1's
for i = 1:NN
    for j = i+1:NN
        new_one = zeros(1,NN);
        new_one(i)=2;
        new_one(j)=1;
        multipliers = [multipliers;new_one];
    end
end

% (so far, had only written the coefficients of the linear combination)

additional_stoichiometry = multipliers * stoichiometry_constraints;

