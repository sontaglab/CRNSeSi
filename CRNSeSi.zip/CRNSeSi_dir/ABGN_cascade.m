N=11;

Q = [...
%     E  M0 A  M1 G  B  N0 C  N1 F  D
     -1 -1  1  0  0  0  0  0  0  0  0
      1  1 -1  0  0  0  0  0  0  0  0
      1  0 -1  1  0  0  0  0  0  0  0
      0  0  0 -1 -1  1  0  0  0  0  0
      0  0  0  1  1 -1  0  0  0  0  0
      0  1  0  0  1 -1  0  0  0  0  0  
      0  0  0 -1  0  0 -1  1  0  0  0  
      0  0  0  1  0  0  1 -1  0  0  0  
      0  0  0  1  0  0  0 -1  1  0  0
      0  0  0  0  0  0  0  0 -1 -1  1
      0  0  0  0  0  0  0  0  1  1 -1
      0  0  0  0  0  0  1  0  0  1 -1];

G=Q';

% G is 11x12 and has rank 6, so 5 conservations

B =  (G>0).*G;
A = -(G<0).*G;

% debug, should be zero:
% sum(sum(G - (B-A)))

% all conservations, to move:

%E + A               = ET
%G + B               = GT
%F + D               = FT
%M0 + A + M1 + B + C = MT
%N0 + C + N1 + D     = NT

all_possible_conservations=[...
%E  M0 A  M1 G  B  N0 C  N1 F  D
 1  0  1  0  0  0  0  0  0  0  0 
 0  0  0  0  1  1  0  0  0  0  0 
 0  0  0  0  0  0  0  0  0  1  1
 0  1  1  1  0  1  0  1  0  0  0
 0  0  0  0  0  0  1  1  1  0  1];

% debug, should be 0:
%sum(sum(abs(all_possible_conservations*G)))
