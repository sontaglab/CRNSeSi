% saved already in ABGN_cascade:

stoichiometry_constraints = all_possible_conservations([2 3 4 5],:);

