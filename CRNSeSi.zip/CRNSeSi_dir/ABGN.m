N=8;
% rows:  L1 L1p L2 L2p L3 L3p L4 L4p
G = [...
-1 1 0 0 0;
1 -1 0 0 0;
0 -1 1 0 0;
0 1 -1 0 0;
0 0 -1 1 0;
0 0 1 -1 0;
0 0 0 -1 1;
0 0 0 1 -1]

B =  (G>0).*G;
A = -(G<0).*G;
% debug, should be zero: 
%G - (B-A)

