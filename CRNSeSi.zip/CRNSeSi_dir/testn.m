function ans = testn(A,B,n)
 G = B-A;
 v = n*G;
 vvp = (v>0).*v;
 vvn = -(v<0).*v;
%  display('debug: zero?')
%  debug = sum(abs(v - (vvp-vvn)))
 vvpA = sign(vvp * A');
 vvnA = sign(vvn * A');
 ans = (sum(vvpA.*vvnA)==0);
%   debug:
%   if ans==0
%     n
%     v
%     [vvp;vvn]
%     [vvpA;vvnA]
%   end
end

