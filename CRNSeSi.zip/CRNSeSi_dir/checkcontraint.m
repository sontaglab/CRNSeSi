function possible_signs = checkcontrain(constraint,possible_signs);
%    display('calling checkcontrain')
    howmany_possible_signs = size(possible_signs,1);
    i=1;
    while i <= howmany_possible_signs
%        display('before testing:')
%        size(possible_signs,1)
%        i
        XNOR = testsp(constraint,possible_signs(i,:));
        if XNOR==0 %delete that possible sign
%           display('after deleting:')
           howmany_possible_signs = howmany_possible_signs-1;
           possible_signs(i,:)=[];
% debug:
%mm = size(possible_signs,1);
%if  mod(mm, 1000)==0
%  i
%  size(possible_signs,1)
%end
        else
           i=i+1;  %advance to next entry; else stay at same (is really next)
        end
    end
%display('exiting checkcontrain')    
end
